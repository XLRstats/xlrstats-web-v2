<?php
 $hide_menu_header = 1;
?>
